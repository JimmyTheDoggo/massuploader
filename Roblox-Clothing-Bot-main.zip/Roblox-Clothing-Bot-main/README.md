# https://discord.gg/bmVS7Z4HkC
# WARNING: IT COSTS 10 ROBUX TO UPLOAD EACH CLOTHING

# Roblox Clothing Bot
# Features
Mass clothing downloader
 - Template changer (prevents copyright, automatic clothing deletions)
 - Searches maximum catalog pages
 - Decide what sort to search in

Clothing Uploader
 - Integrates with mass clothing downloader to upload clothing
 - Set a limit of max robux to spend
 - Detects ratelimits, and other user errors
 
 # Setup
- Make sure you have python 3.10.0 installed, with add to path option checked during installation, and run Requirements.bat to install all required modules

Open config.ini fill in your details
- Follow the format how it already is
- Save the file config.ini

Go to Clothing DOWNLOADER
- Select your type shirt or pants
- Enter keywords of the type of clothing you want
- Afterwards, press enter and it will download all (100 max)

Go to Clothing UPLOADER, and the magic begins.

_____________________________________________________________________

**Donate to support my work - it's massively appreciated**

<a href="https://www.buymeacoffee.com/adaks"><img src="https://img.buymeacoffee.com/button-api/?text=Buy me a coffee&emoji=&slug=adaks&button_colour=FFDD00&font_colour=000000&font_family=Poppins&outline_colour=000000&coffee_colour=FFDD00" /></a>
